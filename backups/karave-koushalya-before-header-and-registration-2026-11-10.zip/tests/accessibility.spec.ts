import { expect, test } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

for (const language of ["kn", "en"] as const) {
  test(`${language} pages and registration dialog pass automated accessibility checks`, async ({ page }) => {
    test.setTimeout(120_000);
    await page.goto("/");
    if (language === "en") await page.getByRole("button", { name: "English", exact: true }).click();

    for (const route of ["home", "about", "programs", "join"]) {
      await test.step(route, async () => {
        await page.goto(`/#/${route}`);
        await page.evaluate(() => document.fonts.ready);
        if (route === "programs") {
          // Details remain optional to visitors, but their expanded content is audited too.
          for (const summary of await page.locator("main details summary").all()) await summary.click();
        }
        const result = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa"]).analyze();
        expect.soft(result.violations, `${language} ${route}`).toEqual([]);
      });
    }

    await page.getByTestId("register-candidate").click();
    const result = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa"]).analyze();
    expect(result.violations).toEqual([]);
  });
}
