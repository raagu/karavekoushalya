# Karave Koushalya

The Kannada / English website for the Karave Koushalya initiative under Karnataka Rakshana Vedike. Built with React, TypeScript and Vite.

## Run locally

Requires Node.js 22.18 or newer and npm.

```sh
npm ci
npm run dev -- --port 5178 --strictPort
```

Open `http://127.0.0.1:5178`. Kannada is the default language. The English/Kannada toggle remembers the visitor’s choice in that browser.

## Website structure

- **Home:** a concise introduction, T. A. Narayana Gowda’s portrait, vision, mission and three program summaries.
- **About us:** the initiative’s purpose, leadership, principles and optional future direction.
- **Our programs:** skills and certification, career guidance and mentorship, employment and entrepreneurship. Further details expand on request.
- **Get involved:** candidate, organisation, mentor and guidance registrations, plus administrator access.

Older career-pathway and mentorship links still open the relevant program information.

The design uses navy, ivory, restrained red and gold accents, readable bilingual typography, and one consistent responsive header. The supplied Kannada “ಕ” / gear logo and portrait remain the brand assets.

## Current scope

Every registration option displays **The option coming soon**. No forms, accounts, registration requests, analytics or database storage are implemented. Only the language preference is stored in the browser.

Services and partnerships remain plans in development. No existing enrollment totals, unconfirmed partners, government approvals, guaranteed jobs or funding approvals are presented as achievements.

## Build and check

```sh
npm run build
npm test
npm run preview
```

Production files are written to `dist/`. The site uses hash routes, so static hosting needs no route rewrite rules.

Browser checks cover desktop and mobile layouts, header alignment, Kannada/English persistence, leadership/vision/mission content, expandable program information, legacy links, registration dialogs, focus handling and automated accessibility. If needed, install the browser with `npx playwright install chromium`. The configuration can reuse an installed Chromium cache or `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH`.

## Content and assets

- `src/siteContent.ts`: concise bilingual content used by the current website.
- `src/App.tsx`: views, navigation and registration dialogs.
- `src/styles.css`: the corporate theme and responsive layouts.
- `src/content.ts`: the earlier detailed program reference, retained for future development.
- `public/images/narayana-gowda.jpeg`: the supplied portrait, unchanged.
- `public/images/karave-koushalya-logo-v3.png`: the Kannada-and-skill logo.

The source vision is the user-provided `karave_koushalya.md`. Fonts are bundled locally with their SIL Open Font Licenses in `public/fonts/`. The website makes no third-party font or image requests.

The previous website source is preserved in `backups/karave-koushalya-before-redesign-2026-11-10.zip`. Restore those source files and rebuild to return to that version.

Hosting/domain setup, live registration, authentication, data storage and operational monitoring are future work.
