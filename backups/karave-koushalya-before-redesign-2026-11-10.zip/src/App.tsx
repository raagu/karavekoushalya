import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Award,
  BookOpen,
  BriefcaseBusiness,
  Building2,
  Check,
  Code2,
  Compass,
  GraduationCap,
  Handshake,
  Heart,
  Languages,
  Lightbulb,
  MapPin,
  Menu,
  ShieldCheck,
  Sparkles,
  Sprout,
  Target,
  Users,
  Wrench,
  X,
} from "lucide-react";
import {
  flagships,
  groups,
  mentoringTracks,
  roadmap,
  roles,
  skillFeatures,
  stakeholders,
  type Lang,
  type Localized,
} from "./content";

type Page = "home" | "pathways" | "programs" | "mentorship" | "about" | "join";
type Role = "candidate" | "corporate" | "mentor" | "mentee" | "admin";
const pages: Page[] = [
  "home",
  "pathways",
  "programs",
  "mentorship",
  "about",
  "join",
];
const text = (en: string, kn: string): Localized => ({ en, kn });
const nav: Record<Page, Localized> = {
  home: text("Home", "ಮುಖಪುಟ"),
  pathways: text("Career pathways", "ವೃತ್ತಿ ಮಾರ್ಗಗಳು"),
  programs: text("Programs", "ಕಾರ್ಯಕ್ರಮಗಳು"),
  mentorship: text("Mentorship", "ಮಾರ್ಗದರ್ಶನ"),
  about: text("About", "ನಮ್ಮ ಬಗ್ಗೆ"),
  join: text("Join the movement", "ನಮ್ಮೊಂದಿಗೆ ಸೇರಿ"),
};
const groupIcons = [Code2, Building2, Wrench, Heart];
const roleIcons = [GraduationCap, Building2, Compass, Sprout, ShieldCheck];

function currentPage(): Page {
  const value = window.location.hash.replace(/^#\/?/, "").split("?")[0];
  return pages.includes(value as Page) ? (value as Page) : "home";
}

function readLanguage(): Lang {
  try {
    return localStorage.getItem("karave-language") === "en" ? "en" : "kn";
  } catch {
    return "kn";
  }
}

function BrandEmblem() {
  return (
    <img
      className="brand-emblem"
      src="/images/karave-koushalya-logo-v3.png"
      alt=""
      width="1254"
      height="1254"
      decoding="async"
    />
  );
}

export default function App() {
  const [lang, setLang] = useState<Lang>(readLanguage);
  const [page, setPage] = useState<Page>(currentPage);
  const [menuOpen, setMenuOpen] = useState(false);
  const [registration, setRegistration] = useState<Role | null>(null);
  const [openGroup, setOpenGroup] = useState("a");
  const mainRef = useRef<HTMLElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const initialPage = useRef(true);
  const t = (value: Localized) => value[lang];

  useEffect(() => {
    const handleRoute = () => {
      setPage(currentPage());
      setMenuOpen(false);
    };
    window.addEventListener("hashchange", handleRoute);
    return () => window.removeEventListener("hashchange", handleRoute);
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang === "kn" ? "kn" : "en";
    document.title = `${t(nav[page])} · ${lang === "kn" ? "ಕರವೇ ಕೌಶಲ್ಯ" : "Karave Koushalya"}`;
    try {
      localStorage.setItem("karave-language", lang);
    } catch {
      /* Language remains available without storage. */
    }
  }, [lang, page]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
    if (!initialPage.current) mainRef.current?.focus({ preventScroll: true });
    initialPage.current = false;
  }, [page]);

  useEffect(() => {
    if (!menuOpen) return;
    const close = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMenuOpen(false);
        menuButtonRef.current?.focus();
      }
    };
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, [menuOpen]);

  function link(
    destination: Page,
    label: ReactNode,
    className = "",
    extra?: Record<string, string>,
  ) {
    return (
      <a href={`#/${destination}`} className={className} {...extra}>
        {label}
      </a>
    );
  }

  function register(
    role: Role,
    label?: Localized,
    className = "button button-red",
    testId?: string,
  ) {
    return (
      <button
        className={className}
        onClick={() => setRegistration(role)}
        data-testid={testId}
      >
        {label
          ? t(label)
          : t(text("Register interest", "ನೋಂದಣಿಗೆ ಮುಂದುವರಿಯಿರಿ"))}
        <ArrowUpRight size={18} aria-hidden="true" />
      </button>
    );
  }

  const eyebrow = (label: Localized) => (
    <div className="eyebrow">
      <span />
      {t(label)}
    </div>
  );
  const planned = (
    <span className="status">
      <span />
      {t(text("Planned initiative", "ಪ್ರಸ್ತಾವಿತ ಉಪಕ್ರಮ"))}
    </span>
  );

  function sectionHeading(
    kicker: Localized,
    title: Localized,
    description?: Localized,
    action?: ReactNode,
  ) {
    return (
      <div className="section-heading">
        <div>
          {eyebrow(kicker)}
          <h2>{t(title)}</h2>
          {description && <p>{t(description)}</p>}
        </div>
        {action}
      </div>
    );
  }

  function pageHero(
    kicker: Localized,
    title: Localized,
    description: Localized,
    children?: ReactNode,
  ) {
    return (
      <section className="page-hero">
        <div className="container">
          {eyebrow(kicker)}
          <h1>{t(title)}</h1>
          <p>{t(description)}</p>
          {children}
        </div>
        <div className="hero-ring" aria-hidden="true" />
      </section>
    );
  }

  function groupCards() {
    return (
      <div className="pathway-grid">
        {groups.map((group, index) => {
          const Icon = groupIcons[index];
          return (
            <a
              className="pathway-card"
              href="#/pathways"
              key={group.id}
              onClick={() => setOpenGroup(group.id)}
            >
              <div className="card-top">
                <span className="group-tag">
                  {t(text("GROUP", "ವರ್ಗ"))} {group.id.toUpperCase()}
                </span>
                <Icon size={23} strokeWidth={1.6} aria-hidden="true" />
              </div>
              <h3>{t(group.shortTitle)}</h3>
              <p>{t(group.tag)}</p>
              <span className="card-link">
                {t(text("Explore your path", "ನಿಮ್ಮ ಮಾರ್ಗ ಅರಿಯಿರಿ"))}
                <ArrowUpRight size={18} aria-hidden="true" />
              </span>
            </a>
          );
        })}
      </div>
    );
  }

  function joinBanner() {
    return (
      <section className="join-banner container">
        <div className="banner-icon">
          <Sprout size={44} strokeWidth={1.4} aria-hidden="true" />
        </div>
        <div>
          <span className="small-label">
            {t(
              text(
                "LET’S BUILD WHAT COMES NEXT",
                "ಮುಂದಿನ ಹೆಜ್ಜೆಯನ್ನು ಜೊತೆಯಾಗಿ ಇಡೋಣ",
              ),
            )}
          </span>
          <h2>
            {t(
              text(
                "Your ambition. Our shared future.",
                "ನಿಮ್ಮ ಕನಸು. ನಮ್ಮೆಲ್ಲರ ಭವಿಷ್ಯ.",
              ),
            )}
          </h2>
          <p>
            {t(
              text(
                "Learn, guide, hire, or give back. There is a place for you here.",
                "ಕಲಿಯಿರಿ, ಮಾರ್ಗದರ್ಶನ ನೀಡಿ, ನೇಮಕ ಮಾಡಿಕೊಳ್ಳಿ ಅಥವಾ ಬೆಂಬಲಿಸಿ. ಇಲ್ಲಿ ನಿಮಗೂ ಒಂದು ಸ್ಥಾನವಿದೆ.",
              ),
            )}
          </p>
        </div>
        {link(
          "join",
          <>
            {t(text("Find your place", "ನಿಮ್ಮ ಪಾತ್ರ ಆಯ್ಕೆಮಾಡಿ"))}
            <ArrowUpRight size={19} aria-hidden="true" />
          </>,
          "button button-dark",
        )}
      </section>
    );
  }

  function Home() {
    return (
      <>
        <section className="home-hero">
          <div className="container hero-layout">
            <div className="hero-copy">
              {planned}
              <div className="hero-overline">
                {t(
                  text(
                    "ROOTED IN KARNATAKA. READY FOR TOMORROW.",
                    "ಕರ್ನಾಟಕದ ನೆಲೆಯಿಂದ. ನಾಳಿನ ಅವಕಾಶಗಳತ್ತ.",
                  ),
                )}
              </div>
              <h1>
                {lang === "en" ? (
                  <>
                    Local roots.
                    <br />
                    Limitless <span>possibilities.</span>
                  </>
                ) : (
                  <>
                    ಕನ್ನಡದ ನೆಲೆ.
                    <br />
                    <span>
                      ಅವಕಾಶಗಳಿಗೆ
                      <br className="kn-break" /> ಎಲ್ಲೆಯಿಲ್ಲ.
                    </span>
                  </>
                )}
              </h1>
              <p className="hero-tagline">
                {t(
                  text(
                    "Skills for Kannadigas. Opportunity for everyone.",
                    "ಕನ್ನಡಿಗರಿಗೆ ಕೌಶಲ್ಯ — ಪ್ರತಿಯೊಬ್ಬರಿಗೂ ಉದ್ಯೋಗ.",
                  ),
                )}
              </p>
              <p className="hero-description">
                {t(
                  text(
                    "A new chapter in learning, skills, and employment. Bringing Karnataka’s youth, mentors, and employers together to turn potential into opportunity.",
                    "ಕಲಿಕೆ, ಕೌಶಲ್ಯ ಮತ್ತು ಉದ್ಯೋಗಕ್ಕೆ ಹೊಸ ದಾರಿ. ಕರ್ನಾಟಕದ ಯುವಜನರು, ಮಾರ್ಗದರ್ಶಕರು ಮತ್ತು ಉದ್ಯೋಗದಾತರನ್ನು ಒಂದೆಡೆ ಸೇರಿಸಿ, ಸಾಮರ್ಥ್ಯವನ್ನು ಅವಕಾಶವಾಗಿ ರೂಪಿಸುವ ಪ್ರಯತ್ನ.",
                  ),
                )}
              </p>
              <div className="hero-actions">
                {link(
                  "pathways",
                  <>
                    {t(
                      text(
                        "Discover your pathway",
                        "ನಿಮ್ಮ ವೃತ್ತಿ ಮಾರ್ಗ ಅರಿಯಿರಿ",
                      ),
                    )}
                    <ArrowUpRight size={19} aria-hidden="true" />
                  </>,
                  "button button-red",
                )}
                {link(
                  "programs",
                  <>
                    {t(text("Explore programs", "ಕಾರ್ಯಕ್ರಮಗಳನ್ನು ನೋಡಿ"))}
                    <ArrowRight size={18} aria-hidden="true" />
                  </>,
                  "button button-plain",
                )}
              </div>
              <div className="hero-note">
                <MapPin size={16} aria-hidden="true" />
                <span>
                  {t(
                    text(
                      "One vision. Every district of Karnataka.",
                      "ಒಂದೇ ಧ್ಯೇಯ. ಕರ್ನಾಟಕದ ಪ್ರತಿ ಜಿಲ್ಲೆಯತ್ತ.",
                    ),
                  )}
                </span>
              </div>
            </div>
            <div className="hero-visual">
              <div className="portrait-topline">
                <span className="mini-flag" />
                <span>
                  {t(
                    text("KARNATAKA RAKSHANA VEDIKE", "ಕರ್ನಾಟಕ ರಕ್ಷಣಾ ವೇದಿಕೆ"),
                  )}
                </span>
              </div>
              <div className="portrait-image">
                <img
                  src="/images/narayana-gowda.jpeg"
                  alt={t(
                    text(
                      "T. A. Narayana Gowda wearing a yellow and red turban and scarf",
                      "ಹಳದಿ ಮತ್ತು ಕೆಂಪು ಪೇಟ ಹಾಗೂ ಶಾಲು ಧರಿಸಿರುವ ತ.ನಾ. ನಾರಾಯಣ ಗೌಡರು",
                    ),
                  )}
                  width="400"
                  height="400"
                  fetchPriority="high"
                />
              </div>
              <div className="portrait-caption">
                <div>
                  <span className="small-label">
                    {t(text("UNDER THE LEADERSHIP OF", "ಇವರ ನೇತೃತ್ವದಲ್ಲಿ"))}
                  </span>
                  <h2>
                    {t(text("T. A. Narayana Gowda", "ತ.ನಾ. ನಾರಾಯಣ ಗೌಡರು"))}
                  </h2>
                  <p>
                    {t(
                      text(
                        "Karnataka Rakshana Vedike",
                        "ಕರ್ನಾಟಕ ರಕ್ಷಣಾ ವೇದಿಕೆ",
                      ),
                    )}
                  </p>
                </div>
                <span className="portrait-seal" aria-hidden="true">
                  <BrandEmblem />
                </span>
              </div>
              <div className="portrait-side" aria-hidden="true">
                ಕಲಿಕೆ · ಕೌಶಲ್ಯ · ಉದ್ಯೋಗ
              </div>
            </div>
          </div>
          <div className="hero-bottom">
            <div className="container">
              <span>ಕಲಿಕೆ</span>
              <span className="red-dot" />
              <span>{t(text("LEARNING", "ಕೌಶಲ್ಯ"))}</span>
              <span className="red-dot" />
              <span>{t(text("SKILLS", "ಉದ್ಯೋಗ"))}</span>
              <span className="red-dot" />
              <span>{t(text("OPPORTUNITY", "ಸಬಲೀಕರಣ"))}</span>
              <ArrowDown size={18} aria-hidden="true" />
            </div>
          </div>
        </section>

        <section
          className="vision-strip container"
          aria-label={t(text("Platform vision", "ವೇದಿಕೆಯ ಧ್ಯೇಯ"))}
        >
          <div className="vision-intro">
            <span className="small-label">
              {t(text("A VISION FOR KARNATAKA", "ಕರ್ನಾಟಕಕ್ಕಾಗಿ ಒಂದು ಧ್ಯೇಯ"))}
            </span>
            <p>
              {t(
                text(
                  "Every skill matters. Every ambition belongs.",
                  "ಪ್ರತಿ ಕೌಶಲ್ಯಕ್ಕೂ ಮೌಲ್ಯ. ಪ್ರತಿ ಕನಸಿಗೂ ಒಂದು ದಾರಿ.",
                ),
              )}
            </p>
          </div>
          {[
            {
              value: "04",
              label: text(
                "Inclusive career groups",
                "ಎಲ್ಲರನ್ನೂ ಒಳಗೊಂಡ ವೃತ್ತಿ ವರ್ಗಗಳು",
              ),
            },
            {
              value: "03",
              label: text("Core program pillars", "ಪ್ರಮುಖ ಕಾರ್ಯಕ್ರಮ ವಿಭಾಗಗಳು"),
            },
            {
              value: "31",
              label: text("Districts in the vision", "ಜಿಲ್ಲೆಗಳಿಗೆ ತಲುಪುವ ಗುರಿ"),
            },
          ].map((item) => (
            <div className="vision-stat" key={item.value}>
              <strong>{item.value}</strong>
              <span>{t(item.label)}</span>
            </div>
          ))}
        </section>

        <section className="section container">
          {sectionHeading(
            text("FIND YOUR DIRECTION", "ನಿಮ್ಮ ದಾರಿ ಕಂಡುಕೊಳ್ಳಿ"),
            text(
              "Different journeys.\nOne shared ambition.",
              "ದಾರಿಗಳು ಹಲವು.\nಸಬಲೀಕರಣದ ಧ್ಯೇಯ ಒಂದೇ.",
            ),
            text(
              "From your first job to your next big leap, explore a pathway built around your skills and aspirations.",
              "ಮೊದಲ ಉದ್ಯೋಗದಿಂದ ಮುಂದಿನ ಸಾಧನೆಯವರೆಗೆ, ನಿಮ್ಮ ಕೌಶಲ್ಯ ಮತ್ತು ಆಸಕ್ತಿಗೆ ತಕ್ಕ ಮಾರ್ಗವನ್ನು ಅರಿಯಿರಿ.",
            ),
            link(
              "pathways",
              <>
                {t(text("All career pathways", "ಎಲ್ಲ ವೃತ್ತಿ ಮಾರ್ಗಗಳು"))}
                <ArrowUpRight size={18} aria-hidden="true" />
              </>,
              "text-link",
            ),
          )}
          {groupCards()}
        </section>

        <section className="pillars-section">
          <div className="container section">
            {sectionHeading(
              text("MORE THAN A SKILLING PLATFORM", "ಕೌಶಲ್ಯದಾಚೆಗೂ ಒಂದು ಹೆಜ್ಜೆ"),
              text(
                "The support to move forward.",
                "ಮುಂದೆ ಸಾಗಲು ಸಂಪೂರ್ಣ ಬೆಂಬಲ.",
              ),
              text(
                "Three connected pillars. One ecosystem designed to help Karnataka’s talent thrive.",
                "ಮೂರು ಪರಸ್ಪರ ಪೂರಕ ವಿಭಾಗಗಳು. ಕರ್ನಾಟಕದ ಪ್ರತಿಭೆಗೆ ಬೆಳವಣಿಗೆಯ ಸಮಗ್ರ ಪರಿಸರ.",
              ),
            )}
            <div className="pillar-grid">
              {[
                {
                  icon: Award,
                  n: "01",
                  title: text(
                    "Skills that open doors",
                    "ಅವಕಾಶಗಳ ಬಾಗಿಲು ತೆರೆಯುವ ಕೌಶಲ್ಯ",
                  ),
                  body: text(
                    "Structured training, skill assessments, student chapters, and proposed digital credentials across Groups A–D.",
                    "ಎ–ಡಿ ವರ್ಗಗಳಿಗೆ ರೂಪಿತ ತರಬೇತಿ, ಕೌಶಲ್ಯ ಮೌಲ್ಯಮಾಪನ, ವಿದ್ಯಾರ್ಥಿ ಘಟಕಗಳು ಮತ್ತು ಪ್ರಸ್ತಾವಿತ ಡಿಜಿಟಲ್ ಪ್ರಮಾಣಪತ್ರಗಳು.",
                  ),
                  page: "programs" as Page,
                },
                {
                  icon: Users,
                  n: "02",
                  title: text(
                    "Guidance that goes further",
                    "ಮುನ್ನಡೆಸುವ ಮಾರ್ಗದರ್ಶನ",
                  ),
                  body: text(
                    "Career roadmaps, one-to-one mentoring, and practical workshops with experienced professionals.",
                    "ಅನುಭವಿ ವೃತ್ತಿಪರರಿಂದ ವೃತ್ತಿ ರೂಪರೇಷೆ, ವೈಯಕ್ತಿಕ ಮಾರ್ಗದರ್ಶನ ಮತ್ತು ಪ್ರಾಯೋಗಿಕ ಕಾರ್ಯಾಗಾರಗಳು.",
                  ),
                  page: "mentorship" as Page,
                },
                {
                  icon: Sprout,
                  n: "03",
                  title: text("Opportunity in action", "ಅವಕಾಶಕ್ಕೆ ಕಾರ್ಯರೂಪ"),
                  body: text(
                    "Planned paid apprenticeships, entrepreneurship support, and Kannada–English workplace fluency.",
                    "ಪ್ರಸ್ತಾವಿತ ಗೌರವಧನ ಸಹಿತ ತರಬೇತಿ, ಉದ್ಯಮಶೀಲತೆಗೆ ಬೆಂಬಲ ಮತ್ತು ಕನ್ನಡ–ಇಂಗ್ಲಿಷ್ ವೃತ್ತಿ ಸಂವಹನ.",
                  ),
                  page: "programs" as Page,
                },
              ].map(({ icon: Icon, ...item }) => (
                <a href={`#/${item.page}`} className="pillar-card" key={item.n}>
                  <div className="pillar-number">
                    <Icon size={28} strokeWidth={1.6} aria-hidden="true" />
                    <span>{item.n}</span>
                  </div>
                  <h3>{t(item.title)}</h3>
                  <p>{t(item.body)}</p>
                  <span className="card-link">
                    {t(text("Discover more", "ಇನ್ನಷ್ಟು ತಿಳಿಯಿರಿ"))}
                    <ArrowUpRight size={18} aria-hidden="true" />
                  </span>
                </a>
              ))}
            </div>
          </div>
        </section>

        <section className="section container story-teaser">
          <div className="story-art" aria-hidden="true">
            <span className="story-word">
              ನಮ್ಮ
              <br />
              ನಾಡು.
              <br />
              <em>
                ನಮ್ಮ
                <br />
                ಭವಿಷ್ಯ.
              </em>
            </span>
            <div className="art-rays" />
          </div>
          <div className="story-copy">
            {eyebrow(text("FROM VOICE TO OPPORTUNITY", "ಆಗ್ರಹದಿಂದ ಅವಕಾಶದತ್ತ"))}
            <h2>
              {t(
                text(
                  "Our roots run deep.\nOur vision reaches further.",
                  "ನಮ್ಮ ನೆಲೆ ಗಟ್ಟಿ.\nನಮ್ಮ ಕನಸು ವಿಸ್ತಾರ.",
                ),
              )}
            </h2>
            <p>
              {t(
                text(
                  "Building on KaRaVe’s long-standing advocacy for Kannada and Kannadigas, Karave Koushalya proposes a practical bridge between local talent and the world of work.",
                  "ಕನ್ನಡ ಮತ್ತು ಕನ್ನಡಿಗರ ಪರ ಕರವೇ ನಡೆಸಿಕೊಂಡು ಬಂದಿರುವ ಹೋರಾಟದ ನೆಲೆಯಲ್ಲಿ, ಸ್ಥಳೀಯ ಪ್ರತಿಭೆ ಮತ್ತು ಉದ್ಯೋಗ ಜಗತ್ತಿನ ನಡುವೆ ಪ್ರಾಯೋಗಿಕ ಸೇತು ನಿರ್ಮಿಸುವುದು ಕರವೇ ಕೌಶಲ್ಯದ ಉದ್ದೇಶ.",
                ),
              )}
            </p>
            <p>
              {t(
                text(
                  "Learning. Skills. Employment. A shared commitment to a more capable, confident Karnataka.",
                  "ಕಲಿಕೆ. ಕೌಶಲ್ಯ. ಉದ್ಯೋಗ. ಸಮರ್ಥ, ಆತ್ಮವಿಶ್ವಾಸದ ಕರ್ನಾಟಕಕ್ಕಾಗಿ ಒಂದು ಸಾಮೂಹಿಕ ಬದ್ಧತೆ.",
                ),
              )}
            </p>
            {link(
              "about",
              <>
                {t(
                  text(
                    "The story behind the movement",
                    "ಉಪಕ್ರಮದ ಹಿನ್ನೆಲೆ ತಿಳಿಯಿರಿ",
                  ),
                )}
                <ArrowUpRight size={18} aria-hidden="true" />
              </>,
              "text-link",
            )}
          </div>
        </section>
        {joinBanner()}
      </>
    );
  }

  function Pathways() {
    return (
      <>
        {pageHero(
          text(
            "FOUR PATHWAYS. EVERY KANNADIGA.",
            "ನಾಲ್ಕು ಮಾರ್ಗಗಳು. ಪ್ರತಿಯೊಬ್ಬ ಕನ್ನಡಿಗರಿಗಾಗಿ.",
          ),
          text("A path for every ambition.", "ಪ್ರತಿ ಕನಸಿಗೂ ಒಂದು ವೃತ್ತಿ ಮಾರ್ಗ."),
          text(
            "Your starting point should never limit your destination. Explore planned training, guidance, and career opportunities across the full spectrum of work.",
            "ನಿಮ್ಮ ಇಂದಿನ ಸ್ಥಿತಿ ನಾಳಿನ ಸಾಧನೆಯನ್ನು ಸೀಮಿತಗೊಳಿಸದಿರಲಿ. ಎಲ್ಲ ವೃತ್ತಿ ವಲಯಗಳ ಪ್ರಸ್ತಾವಿತ ತರಬೇತಿ, ಮಾರ್ಗದರ್ಶನ ಮತ್ತು ಅವಕಾಶಗಳನ್ನು ಅರಿಯಿರಿ.",
          ),
        )}
        <section className="section container">
          <div
            className="pathway-tabs"
            role="tablist"
            aria-label={t(text("Career groups", "ವೃತ್ತಿ ವರ್ಗಗಳು"))}
          >
            {groups.map((group, i) => {
              const Icon = groupIcons[i];
              return (
                <button
                  role="tab"
                  id={`tab-${group.id}`}
                  aria-controls={`panel-${group.id}`}
                  aria-selected={openGroup === group.id}
                  tabIndex={openGroup === group.id ? 0 : -1}
                  className={openGroup === group.id ? "active" : ""}
                  key={group.id}
                  onClick={() => setOpenGroup(group.id)}
                  onKeyDown={(event) => {
                    let next: number | undefined;
                    if (event.key === "ArrowRight")
                      next = (i + 1) % groups.length;
                    if (event.key === "ArrowLeft")
                      next = (i + groups.length - 1) % groups.length;
                    if (event.key === "Home") next = 0;
                    if (event.key === "End") next = groups.length - 1;
                    if (next !== undefined) {
                      event.preventDefault();
                      setOpenGroup(groups[next].id);
                      document
                        .getElementById(`tab-${groups[next].id}`)
                        ?.focus();
                    }
                  }}
                >
                  <Icon size={21} aria-hidden="true" />
                  <span>
                    {t(text("Group", "ವರ್ಗ"))} {group.id.toUpperCase()}
                    <small>{t(group.shortTitle)}</small>
                  </span>
                </button>
              );
            })}
          </div>
          {groups.map((group) => (
            <div
              role="tabpanel"
              id={`panel-${group.id}`}
              aria-labelledby={`tab-${group.id}`}
              hidden={openGroup !== group.id}
              key={group.id}
              tabIndex={0}
              className="pathway-detail"
            >
              <div className="pathway-detail-intro">
                <div className="large-group">
                  {group.id.toUpperCase()}
                  <span>{t(text("YOUR PATHWAY", "ನಿಮ್ಮ ಮಾರ್ಗ"))}</span>
                </div>
                <div>
                  {planned}
                  <h2>{t(group.title)}</h2>
                  <span className="small-label">
                    {t(text("WHO THIS IS FOR", "ಯಾರಿಗಾಗಿ"))}
                  </span>
                  <p>{t(group.audience)}</p>
                </div>
              </div>
              <div className="detail-columns">
                <div>
                  <h3>
                    <BookOpen size={20} aria-hidden="true" />
                    {t(text("Areas to explore", "ಕಲಿಕೆಯ ಕ್ಷೇತ್ರಗಳು"))}
                  </h3>
                  <ul className="check-list">
                    {group.domains.map((domain) => (
                      <li key={domain.en}>
                        <Check size={17} aria-hidden="true" />
                        {t(domain)}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="focus-panel">
                  <Target size={28} strokeWidth={1.5} aria-hidden="true" />
                  <h3>
                    {t(
                      text("Your growth, in focus", "ನಿಮ್ಮ ಬೆಳವಣಿಗೆಗೆ ಆದ್ಯತೆ"),
                    )}
                  </h3>
                  <p>{t(group.focus)}</p>
                  {register(
                    "candidate",
                    text("Join as a candidate", "ಅಭ್ಯರ್ಥಿಯಾಗಿ ಸೇರಿ"),
                  )}
                </div>
              </div>
            </div>
          ))}
        </section>
        <section className="container note-band">
          <Lightbulb size={25} aria-hidden="true" />
          <p>
            {t(
              text(
                "Not sure where to start? The planned mentoring ecosystem will help candidates explore their strengths and choose a direction. Registration is coming soon.",
                "ಎಲ್ಲಿಂದ ಆರಂಭಿಸಬೇಕು ಎಂಬ ಗೊಂದಲವೇ? ನಿಮ್ಮ ಸಾಮರ್ಥ್ಯ ಅರಿತು ಸರಿಯಾದ ಮಾರ್ಗ ಆಯ್ಕೆಮಾಡಲು ಪ್ರಸ್ತಾವಿತ ಮಾರ್ಗದರ್ಶನ ವ್ಯವಸ್ಥೆ ನೆರವಾಗಲಿದೆ. ನೋಂದಣಿ ಶೀಘ್ರದಲ್ಲೇ.",
              ),
            )}
          </p>
        </section>
        {joinBanner()}
      </>
    );
  }

  function Programs() {
    return (
      <>
        {pageHero(
          text("LEARNING WITH PURPOSE", "ಉದ್ದೇಶಪೂರ್ಣ ಕಲಿಕೆ"),
          text("Learn. Grow. Move forward.", "ಕಲಿಯಿರಿ. ಬೆಳೆಯಿರಿ. ಮುಂದೆ ಸಾಗಿ."),
          text(
            "Discover the full program vision: practical skills, professional communities, work experience, and the confidence to build your own future.",
            "ಪ್ರಾಯೋಗಿಕ ಕೌಶಲ್ಯ, ವೃತ್ತಿಪರ ಸಮುದಾಯ, ಕೆಲಸದ ಅನುಭವ ಮತ್ತು ನಿಮ್ಮ ಭವಿಷ್ಯ ಕಟ್ಟಿಕೊಳ್ಳುವ ಆತ್ಮವಿಶ್ವಾಸ — ಕಾರ್ಯಕ್ರಮಗಳ ಸಂಪೂರ್ಣ ರೂಪರೇಷೆಯನ್ನು ತಿಳಿಯಿರಿ.",
          ),
        )}
        <section className="section container">
          {sectionHeading(
            text("PILLAR 01", "ವಿಭಾಗ 01"),
            text("Skilling & certification", "ಕೌಶಲ್ಯ ತರಬೇತಿ ಮತ್ತು ಪ್ರಮಾಣೀಕರಣ"),
            text(
              "A proposed assessment-led system, inspired by the Computer Society of India’s institutional model. Inspiration does not imply affiliation or accreditation.",
              "ಕಂಪ್ಯೂಟರ್ ಸೊಸೈಟಿ ಆಫ್ ಇಂಡಿಯಾದ ಸಾಂಸ್ಥಿಕ ಮಾದರಿಯಿಂದ ಪ್ರೇರಿತವಾದ ಪ್ರಸ್ತಾವಿತ ಮೌಲ್ಯಮಾಪನ ಆಧಾರಿತ ವ್ಯವಸ್ಥೆ. ಈ ಪ್ರೇರಣೆ ಸಂಸ್ಥೆಯ ಸಹಭಾಗಿತ್ವ ಅಥವಾ ಮಾನ್ಯತೆಯನ್ನು ಸೂಚಿಸುವುದಿಲ್ಲ.",
            ),
          )}
          <div className="feature-grid">
            {skillFeatures.map((feature, i) => (
              <article className="feature-card" key={feature.title.en}>
                <span className="feature-index">0{i + 1}</span>
                <h3>{t(feature.title)}</h3>
                <p>{t(feature.description)}</p>
                {feature.items && (
                  <ul className="bullet-list">
                    {feature.items.map((item) => (
                      <li key={item.en}>{t(item)}</li>
                    ))}
                  </ul>
                )}
              </article>
            ))}
          </div>
          <div className="credential-note">
            <Award size={25} aria-hidden="true" />
            <p>
              {t(
                text(
                  "Planned credential: “KaRaVe Certified Kannadiga Talent” with a QR code for employer verification. Assessment standards, recognition, and verification services will be developed before launch.",
                  "ಪ್ರಸ್ತಾವಿತ ಪ್ರಮಾಣಪತ್ರ: ಉದ್ಯೋಗದಾತರ ಪರಿಶೀಲನೆಗಾಗಿ ಕ್ಯೂಆರ್ ಕೋಡ್ ಒಳಗೊಂಡ “ಕರವೇ ಪ್ರಮಾಣೀಕೃತ ಕನ್ನಡಿಗ ಪ್ರತಿಭೆ”. ಮೌಲ್ಯಮಾಪನ ಮಾನದಂಡ, ಮಾನ್ಯತೆ ಮತ್ತು ಪರಿಶೀಲನಾ ವ್ಯವಸ್ಥೆಯನ್ನು ಆರಂಭಕ್ಕೂ ಮುನ್ನ ರೂಪಿಸಲಾಗುತ್ತದೆ.",
                ),
              )}
            </p>
          </div>
        </section>
        <section className="mentorship-strip">
          <div className="container">
            <div className="strip-icon">
              <Users size={36} aria-hidden="true" />
            </div>
            <div>
              <span className="small-label">
                {t(text("PILLAR 02", "ವಿಭಾಗ 02"))}
              </span>
              <h2>
                {t(
                  text(
                    "You don’t have to figure it out alone.",
                    "ಎಲ್ಲವನ್ನೂ ಒಬ್ಬರೇ ಕಂಡುಕೊಳ್ಳಬೇಕಿಲ್ಲ.",
                  ),
                )}
              </h2>
              <p>
                {t(
                  text(
                    "Explore one-to-one guidance, career roadmaps, and group workshops.",
                    "ವೈಯಕ್ತಿಕ ಮಾರ್ಗದರ್ಶನ, ವೃತ್ತಿ ರೂಪರೇಷೆ ಮತ್ತು ಗುಂಪು ಕಾರ್ಯಾಗಾರಗಳನ್ನು ಅರಿಯಿರಿ.",
                  ),
                )}
              </p>
            </div>
            {link(
              "mentorship",
              <>
                {t(text("Explore mentorship", "ಮಾರ್ಗದರ್ಶನ ತಿಳಿಯಿರಿ"))}
                <ArrowUpRight size={18} aria-hidden="true" />
              </>,
              "button button-dark",
            )}
          </div>
        </section>
        <section className="section container" id="flagships">
          {sectionHeading(
            text(
              "PILLAR 03 · FLAGSHIP INITIATIVES",
              "ವಿಭಾಗ 03 · ವಿಶೇಷ ಯೋಜನೆಗಳು",
            ),
            text(
              "Real possibilities. Practical support.",
              "ನೈಜ ಸಾಧ್ಯತೆಗಳು. ಪ್ರಾಯೋಗಿಕ ಬೆಂಬಲ.",
            ),
            text(
              "Three proposed initiatives for the challenges that matter: experience, independence, and communication.",
              "ಅನುಭವ, ಸ್ವಾವಲಂಬನೆ ಮತ್ತು ಸಂವಹನ — ಮುಖ್ಯ ಸವಾಲುಗಳಿಗೆ ಮೂರು ಪ್ರಸ್ತಾವಿತ ಉಪಕ್ರಮಗಳು.",
            ),
          )}
          <div className="flagship-list">
            {flagships.map((program, index) => (
              <article className="flagship" key={program.id}>
                <div className="flagship-intro">
                  <span className="flagship-number">0{index + 1}</span>
                  {planned}
                  <h3>{t(program.title)}</h3>
                  {lang === "en" && (
                    <p className="kannada-subtitle" lang="kn">
                      {program.kannadaName}
                    </p>
                  )}
                  <span className="program-subtitle">
                    {t(program.subtitle)}
                  </span>
                  <p>{t(program.description)}</p>
                  {register(
                    "candidate",
                    text("Explore registration", "ನೋಂದಣಿಗೆ ಮುಂದುವರಿಯಿರಿ"),
                    "button button-outline",
                  )}
                </div>
                <div className="flagship-features">
                  {program.features.map((feature) => (
                    <div key={feature.title.en}>
                      <span className="feature-check">
                        <Check size={17} aria-hidden="true" />
                      </span>
                      <div>
                        <h4>{t(feature.title)}</h4>
                        <p>{t(feature.description)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </section>
        {joinBanner()}
      </>
    );
  }

  function Mentorship() {
    return (
      <>
        {pageHero(
          text(
            "EXPERIENCE SHARED. POTENTIAL UNLOCKED.",
            "ಅನುಭವದ ಹಂಚಿಕೆ. ಪ್ರತಿಭೆಗೆ ಹೊಸ ಬೆಳಕು.",
          ),
          text(
            "A little guidance. A bigger future.",
            "ಒಂದು ಮಾರ್ಗದರ್ಶನ. ಉಜ್ವಲ ಭವಿಷ್ಯ.",
          ),
          text(
            "A planned community connecting aspiring Kannadigas with experienced professionals—because skills grow stronger with someone in your corner.",
            "ಕನಸು ಕಾಣುವ ಕನ್ನಡಿಗರನ್ನು ಅನುಭವಿ ವೃತ್ತಿಪರರೊಂದಿಗೆ ಸಂಪರ್ಕಿಸುವ ಪ್ರಸ್ತಾವಿತ ಸಮುದಾಯ. ಬೆಂಬಲ ನೀಡುವ ಒಬ್ಬರಿದ್ದರೆ ಕೌಶಲ್ಯ ಇನ್ನಷ್ಟು ಬಲವಾಗುತ್ತದೆ.",
          ),
        )}
        <section className="section container mentor-intro">
          <div>
            {eyebrow(
              text(
                "A BRIDGE BETWEEN GENERATIONS",
                "ತಲೆಮಾರುಗಳನ್ನು ಬೆಸೆಯುವ ಸೇತು",
              ),
            )}
            <h2>
              {t(
                text(
                  "Share what you know.\nShape what comes next.",
                  "ನಿಮ್ಮ ಅನುಭವ ಹಂಚಿ.\nಮುಂದಿನ ಪೀಳಿಗೆಗೆ ದಾರಿ ತೋರಿ.",
                ),
              )}
            </h2>
            <p>
              {t(
                text(
                  "Inspired by Mentor Together’s one-to-one approach, our proposed dual-track model brings mentors and mentees into structured, purposeful conversations. No formal affiliation is claimed.",
                  "ಮೆಂಟರ್ ಟುಗೆದರ್‌ನ ವೈಯಕ್ತಿಕ ಮಾರ್ಗದರ್ಶನ ವಿಧಾನದಿಂದ ಪ್ರೇರಿತವಾದ ನಮ್ಮ ಪ್ರಸ್ತಾವಿತ ಮಾದರಿ, ಮಾರ್ಗದರ್ಶಕರು ಮತ್ತು ಕಲಿಯುವವರನ್ನು ಉದ್ದೇಶಪೂರ್ಣ ಸಂವಾದಕ್ಕೆ ಒಟ್ಟುಗೂಡಿಸುತ್ತದೆ. ಯಾವುದೇ ಅಧಿಕೃತ ಸಹಭಾಗಿತ್ವವನ್ನು ಘೋಷಿಸಿಲ್ಲ.",
                ),
              )}
            </p>
          </div>
          <div className="mentor-commitment">
            <span>1–2</span>
            <h3>
              {t(
                text(
                  "hours a month can open a world.",
                  "ತಿಂಗಳಿಗೆ ಗಂಟೆಗಳು ಹೊಸ ಜಗತ್ತಿಗೆ ದಾರಿ ತೆರೆಯಬಲ್ಲವು.",
                ),
              )}
            </h3>
            <p>
              {t(
                text(
                  "A proposed volunteering commitment for Kannadiga tech professionals, HR leaders, managers, and civil servants.",
                  "ಕನ್ನಡಿಗ ತಂತ್ರಜ್ಞಾನ ವೃತ್ತಿಪರರು, ಮಾನವ ಸಂಪನ್ಮೂಲ ನಾಯಕರು, ವ್ಯವಸ್ಥಾಪಕರು ಮತ್ತು ಸರ್ಕಾರಿ ಅಧಿಕಾರಿಗಳಿಗಾಗಿ ಪ್ರಸ್ತಾವಿತ ಸ್ವಯಂಸೇವಾ ಬದ್ಧತೆ.",
                ),
              )}
            </p>
          </div>
        </section>
        <section className="container mentor-role-grid">
          <article>
            <span className="icon-tile">
              <Compass size={27} aria-hidden="true" />
            </span>
            <span className="small-label">
              {t(text("FOR MENTORS", "ಮಾರ್ಗದರ್ಶಕರಿಗಾಗಿ"))}
            </span>
            <h2>
              {t(
                text(
                  "Your experience can be someone’s turning point.",
                  "ನಿಮ್ಮ ಅನುಭವ ಇನ್ನೊಬ್ಬರ ಬದುಕಿನ ತಿರುವಾಗಬಹುದು.",
                ),
              )}
            </h2>
            <p>
              {t(
                text(
                  "Help with resumes, mock interviews, industry roadmaps, and the unwritten lessons of working life.",
                  "ಪರಿಚಯಪತ್ರ, ಅಣಕು ಸಂದರ್ಶನ, ಉದ್ಯಮದ ವೃತ್ತಿ ರೂಪರೇಷೆ ಮತ್ತು ಕೆಲಸದ ಅನುಭವದ ಪಾಠಗಳನ್ನು ಹಂಚಿಕೊಳ್ಳಿ.",
                ),
              )}
            </p>
            {register("mentor", text("Become a mentor", "ಮಾರ್ಗದರ್ಶಕರಾಗಿ ಸೇರಿ"))}
          </article>
          <article>
            <span className="icon-tile">
              <Sprout size={27} aria-hidden="true" />
            </span>
            <span className="small-label">
              {t(text("FOR MENTEES", "ಮಾರ್ಗದರ್ಶನ ಪಡೆಯುವವರಿಗಾಗಿ"))}
            </span>
            <h2>
              {t(
                text(
                  "Bring your questions. Find your direction.",
                  "ನಿಮ್ಮ ಪ್ರಶ್ನೆಗಳನ್ನು ತನ್ನಿ. ಮುಂದಿನ ದಾರಿ ಕಂಡುಕೊಳ್ಳಿ.",
                ),
              )}
            </h2>
            <p>
              {t(
                text(
                  "Group A and B aspirants can explore individual career guidance. Group C and D candidates can access planned practical group workshops.",
                  "ಎ ಮತ್ತು ಬಿ ವರ್ಗದ ಆಕಾಂಕ್ಷಿಗಳಿಗೆ ವೈಯಕ್ತಿಕ ವೃತ್ತಿ ಮಾರ್ಗದರ್ಶನ. ಸಿ ಮತ್ತು ಡಿ ವರ್ಗದ ಅಭ್ಯರ್ಥಿಗಳಿಗೆ ಪ್ರಸ್ತಾವಿತ ಪ್ರಾಯೋಗಿಕ ಗುಂಪು ಕಾರ್ಯಾಗಾರಗಳು.",
                ),
              )}
            </p>
            {register(
              "mentee",
              text("Find a mentor", "ಮಾರ್ಗದರ್ಶನ ಪಡೆಯಿರಿ"),
              "button button-dark",
            )}
          </article>
        </section>
        <section className="section container">
          {sectionHeading(
            text(
              "GUIDANCE THAT FITS YOUR JOURNEY",
              "ನಿಮ್ಮ ಪಯಣಕ್ಕೆ ತಕ್ಕ ಮಾರ್ಗದರ್ಶನ",
            ),
            text(
              "Different needs. Thoughtful support.",
              "ವಿವಿಧ ಅಗತ್ಯಗಳು. ಸೂಕ್ತ ಬೆಂಬಲ.",
            ),
          )}
          <div className="mentoring-tracks">
            {mentoringTracks.map((track, i) => (
              <article key={track.title.en}>
                <span className="track-index">0{i + 1}</span>
                <h3>{t(track.title)}</h3>
                <p>{t(track.description)}</p>
                <ul className="bullet-list">
                  {track.items.map((item) => (
                    <li key={item.en}>{t(item)}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </section>
        <section className="container csr-panel">
          <div className="csr-icon">
            <Handshake size={44} strokeWidth={1.4} aria-hidden="true" />
          </div>
          <div>
            {eyebrow(
              text(
                "FOR CORPORATE & CSR PARTNERS",
                "ಕಾರ್ಪೊರೇಟ್ ಮತ್ತು ಸಿಎಸ್‌ಆರ್ ಪಾಲುದಾರರಿಗಾಗಿ",
              ),
            )}
            <h2>
              {t(
                text(
                  "Make expertise your contribution.",
                  "ನಿಮ್ಮ ಪರಿಣತಿಯೇ ನಿಮ್ಮ ಕೊಡುಗೆಯಾಗಲಿ.",
                ),
              )}
            </h2>
            <p>
              {t(
                text(
                  "The planned ecosystem offers Karnataka’s IT parks and companies avenues for employee volunteering, mentoring, and sponsorship of skill bootcamps. Partnerships and CSR arrangements are yet to be established.",
                  "ಕರ್ನಾಟಕದ ಐಟಿ ಪಾರ್ಕ್‌ಗಳು ಮತ್ತು ಕಂಪನಿಗಳ ಉದ್ಯೋಗಿಗಳು ಸ್ವಯಂಸೇವೆ, ಮಾರ್ಗದರ್ಶನ ಮತ್ತು ಕೌಶಲ್ಯ ಶಿಬಿರಗಳಿಗೆ ಪ್ರಾಯೋಜಕತ್ವ ನೀಡಲು ಪ್ರಸ್ತಾವಿತ ವೇದಿಕೆ ಅವಕಾಶ ಕಲ್ಪಿಸಲಿದೆ. ಪಾಲುದಾರಿಕೆ ಮತ್ತು ಸಿಎಸ್‌ಆರ್ ವ್ಯವಸ್ಥೆಗಳನ್ನು ಇನ್ನೂ ಸ್ಥಾಪಿಸಬೇಕಿದೆ.",
                ),
              )}
            </p>
            {register(
              "corporate",
              text("Partner with the initiative", "ಉಪಕ್ರಮಕ್ಕೆ ಬೆಂಬಲ ನೀಡಿ"),
              "button button-outline",
            )}
          </div>
        </section>
        {joinBanner()}
      </>
    );
  }

  function About() {
    return (
      <>
        {pageHero(
          text("OUR PURPOSE", "ನಮ್ಮ ಉದ್ದೇಶ"),
          text("From advocacy to opportunity.", "ಆಗ್ರಹದಿಂದ ಅವಕಾಶದತ್ತ."),
          text(
            "Karave Koushalya is a proposed workforce development initiative of Karnataka Rakshana Vedike, under the leadership of T. A. Narayana Gowda.",
            "ಕರವೇ ಕೌಶಲ್ಯವು ತ.ನಾ. ನಾರಾಯಣ ಗೌಡರ ನೇತೃತ್ವದ ಕರ್ನಾಟಕ ರಕ್ಷಣಾ ವೇದಿಕೆಯ ಪ್ರಸ್ತಾವಿತ ಕೌಶಲ್ಯ ಮತ್ತು ಉದ್ಯೋಗ ಸಬಲೀಕರಣ ಉಪಕ್ರಮವಾಗಿದೆ.",
          ),
        )}
        <section className="section container about-vision">
          <div>
            {eyebrow(text("THE NEXT CHAPTER", "ಮುಂದಿನ ಅಧ್ಯಾಯ"))}
            <h2>
              {t(
                text(
                  "A stronger Karnataka\nstarts with its people.",
                  "ಕರ್ನಾಟಕದ ಶಕ್ತಿ\nಅದರ ಜನರ ಸಾಮರ್ಥ್ಯ.",
                ),
              )}
            </h2>
          </div>
          <div>
            <p>
              {t(
                text(
                  "KaRaVe’s Agraha Abhiyana has advocated for opportunities for local Kannadigas. Karave Koushalya builds on that purpose with a practical vision: help people learn, build confidence, and prepare for work.",
                  "ಕರವೇಯ ಆಗ್ರಹ ಅಭಿಯಾನವು ಸ್ಥಳೀಯ ಕನ್ನಡಿಗರಿಗೆ ಅವಕಾಶಗಳಿಗಾಗಿ ಧ್ವನಿ ಎತ್ತಿದೆ. ಅದೇ ಉದ್ದೇಶಕ್ಕೆ ಪ್ರಾಯೋಗಿಕ ರೂಪ ನೀಡುವುದು ಕರವೇ ಕೌಶಲ್ಯದ ಧ್ಯೇಯ: ಕಲಿಕೆ, ಆತ್ಮವಿಶ್ವಾಸ ಮತ್ತು ಉದ್ಯೋಗ ಸಿದ್ಧತೆಗೆ ನೆರವು.",
                ),
              )}
            </p>
            <p>
              {t(
                text(
                  "The vision extends from engineering graduates in technology parks to technicians, drivers, and support workers across rural and urban Karnataka. Four career groups are designed to make room for every starting point.",
                  "ತಂತ್ರಜ್ಞಾನ ಪಾರ್ಕ್‌ಗಳ ಎಂಜಿನಿಯರಿಂಗ್ ಪದವೀಧರರಿಂದ ಹಿಡಿದು ಗ್ರಾಮೀಣ ಮತ್ತು ನಗರ ಕರ್ನಾಟಕದ ತಂತ್ರಜ್ಞರು, ಚಾಲಕರು ಹಾಗೂ ಸಹಾಯಕ ಸಿಬ್ಬಂದಿಯವರೆಗೆ ಈ ಧ್ಯೇಯ ವಿಸ್ತರಿಸಿದೆ. ಎಲ್ಲರನ್ನೂ ಒಳಗೊಳ್ಳಲು ನಾಲ್ಕು ವೃತ್ತಿ ವರ್ಗಗಳನ್ನು ರೂಪಿಸಲಾಗಿದೆ.",
                ),
              )}
            </p>
            <p>
              {t(
                text(
                  "The strategy draws on the Sarojini Mahishi report’s local-employment aspirations. This is the initiative’s context, rather than a statement of current hiring law or a guarantee of employment.",
                  "ಸ್ಥಳೀಯ ಉದ್ಯೋಗದ ಕುರಿತು ಸರೋಜಿನಿ ಮಹಿಷಿ ವರದಿಯ ಆಶಯಗಳು ಈ ರೂಪರೇಷೆಗೆ ಹಿನ್ನೆಲೆಯಾಗಿವೆ. ಇದು ಉಪಕ್ರಮದ ಸಂದರ್ಭವನ್ನು ವಿವರಿಸುತ್ತದೆ; ಪ್ರಸ್ತುತ ನೇಮಕಾತಿ ಕಾನೂನಿನ ವಿವರಣೆಯೂ ಅಲ್ಲ, ಉದ್ಯೋಗದ ಖಾತರಿಯೂ ಅಲ್ಲ.",
                ),
              )}
            </p>
          </div>
        </section>
        <section className="benefits-section">
          <div className="section container">
            {sectionHeading(
              text("SHARED PROGRESS", "ಸಾಮೂಹಿಕ ಪ್ರಗತಿ"),
              text(
                "When talent grows, everyone moves forward.",
                "ಪ್ರತಿಭೆ ಬೆಳೆದಾಗ ಎಲ್ಲರೂ ಮುಂದೆ ಸಾಗುತ್ತಾರೆ.",
              ),
            )}
            <div className="stakeholder-grid">
              {stakeholders.map((stakeholder, i) => {
                const Icon = [
                  GraduationCap,
                  BriefcaseBusiness,
                  Handshake,
                  Users,
                ][i];
                return (
                  <article key={stakeholder.title.en}>
                    <Icon size={28} strokeWidth={1.5} aria-hidden="true" />
                    <h3>{t(stakeholder.title)}</h3>
                    <p>{t(stakeholder.description)}</p>
                  </article>
                );
              })}
            </div>
          </div>
        </section>
        <section className="section container">
          {sectionHeading(
            text("2026–2027 STRATEGY VISION", "2026–2027ರ ಕಾರ್ಯತಂತ್ರದ ಧ್ಯೇಯ"),
            text(
              "A roadmap. An ambition. A shared effort.",
              "ರೂಪರೇಷೆ. ಮಹತ್ವಾಕಾಂಕ್ಷೆ. ಸಾಮೂಹಿಕ ಪ್ರಯತ್ನ.",
            ),
            text(
              "These are proposed rollout phases and numerical targets from the strategy document—not current enrollment, active partnerships, or completed milestones. Quarter references are planning labels; launch dates are not confirmed.",
              "ಇವು ಕಾರ್ಯತಂತ್ರ ದಾಖಲೆಯ ಪ್ರಸ್ತಾವಿತ ಹಂತಗಳು ಮತ್ತು ಸಂಖ್ಯಾತ್ಮಕ ಗುರಿಗಳು. ಪ್ರಸ್ತುತ ನೋಂದಣಿ, ಚಾಲ್ತಿಯಲ್ಲಿರುವ ಪಾಲುದಾರಿಕೆ ಅಥವಾ ಪೂರ್ಣಗೊಂಡ ಸಾಧನೆಗಳಲ್ಲ. ತ್ರೈಮಾಸಿಕಗಳು ಯೋಜನಾ ಉಲ್ಲೇಖಗಳು; ಆರಂಭದ ದಿನಾಂಕಗಳು ದೃಢಪಟ್ಟಿಲ್ಲ.",
            ),
          )}
          <div className="roadmap">
            {roadmap.map((step, i) => (
              <article key={step.phase}>
                <div className="roadmap-marker">
                  <span>{String(i + 1).padStart(2, "0")}</span>
                </div>
                <div className="roadmap-body">
                  <div className="roadmap-meta">
                    <span>
                      {t(text("PHASE", "ಹಂತ"))} {step.phase}
                    </span>
                    <span>{t(step.period)}</span>
                    <span className="target-label">
                      {t(text("PROPOSED TARGETS", "ಪ್ರಸ್ತಾವಿತ ಗುರಿಗಳು"))}
                    </span>
                  </div>
                  <h3>{t(step.title)}</h3>
                  <p>{t(step.description)}</p>
                  <div className="roadmap-targets">
                    {step.targets.map((target) => (
                      <div key={target.label.en}>
                        <strong>{target.value}</strong>
                        <span>{t(target.label)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>
        <section className="container principles">
          <ShieldCheck size={30} aria-hidden="true" />
          <div>
            <h3>
              {t(
                text(
                  "A clear promise at this stage",
                  "ಈ ಹಂತದಲ್ಲಿ ಸ್ಪಷ್ಟ ಮಾಹಿತಿ",
                ),
              )}
            </h3>
            <p>
              {t(
                text(
                  "This first release introduces the initiative and its plans. Registrations are not open. Training availability, certification recognition, partner participation, financing eligibility, and any government-scheme alignment will be confirmed separately before those services launch.",
                  "ಈ ಮೊದಲ ಆವೃತ್ತಿಯು ಉಪಕ್ರಮ ಮತ್ತು ಅದರ ಯೋಜನೆಗಳನ್ನು ಪರಿಚಯಿಸುತ್ತದೆ. ನೋಂದಣಿ ಇನ್ನೂ ಆರಂಭವಾಗಿಲ್ಲ. ತರಬೇತಿ ಲಭ್ಯತೆ, ಪ್ರಮಾಣಪತ್ರ ಮಾನ್ಯತೆ, ಪಾಲುದಾರರ ಭಾಗವಹಿಸುವಿಕೆ, ಹಣಕಾಸು ಅರ್ಹತೆ ಮತ್ತು ಸರ್ಕಾರಿ ಯೋಜನೆಗಳ ಹೊಂದಾಣಿಕೆಯನ್ನು ಆಯಾ ಸೇವೆಗಳ ಆರಂಭಕ್ಕೂ ಮುನ್ನ ಪ್ರತ್ಯೇಕವಾಗಿ ದೃಢಪಡಿಸಲಾಗುತ್ತದೆ.",
                ),
              )}
            </p>
          </div>
        </section>
        {joinBanner()}
      </>
    );
  }

  function Join() {
    return (
      <>
        {pageHero(
          text(
            "ONE MOVEMENT. MANY WAYS TO BELONG.",
            "ಒಂದು ಅಭಿಯಾನ. ಸೇರಲು ಹಲವು ಮಾರ್ಗಗಳು.",
          ),
          text(
            "Your next chapter starts here.",
            "ನಿಮ್ಮ ಮುಂದಿನ ಅಧ್ಯಾಯ ಇಲ್ಲಿಂದ.",
          ),
          text(
            "A learner, a guide, an employer, or a community builder—choose how you want to be part of Karnataka’s future.",
            "ಕಲಿಯುವವರು, ಮಾರ್ಗದರ್ಶಕರು, ಉದ್ಯೋಗದಾತರು ಅಥವಾ ಸಮುದಾಯ ನಿರ್ಮಿಸುವವರು — ಕರ್ನಾಟಕದ ಭವಿಷ್ಯದಲ್ಲಿ ನಿಮ್ಮ ಪಾತ್ರವನ್ನು ಆರಿಸಿಕೊಳ್ಳಿ.",
          ),
          <div className="join-status">
            <span className="status">
              <span />
              {t(text("Registrations coming soon", "ನೋಂದಣಿ ಶೀಘ್ರದಲ್ಲೇ"))}
            </span>
            <span>
              {t(
                text("Explore the roles below", "ಕೆಳಗಿನ ಪಾತ್ರಗಳನ್ನು ತಿಳಿಯಿರಿ"),
              )}
            </span>
          </div>,
        )}
        <section className="section container">
          <div className="role-grid">
            {roles.map((role, i) => {
              const Icon = roleIcons[i];
              return (
                <article className={`role-card role-${role.id}`} key={role.id}>
                  <div className="role-card-top">
                    <span className="icon-tile">
                      <Icon size={26} strokeWidth={1.6} aria-hidden="true" />
                    </span>
                    <span className="small-label">
                      {t(text("REGISTRATION COMING SOON", "ನೋಂದಣಿ ಶೀಘ್ರದಲ್ಲೇ"))}
                    </span>
                  </div>
                  <h2>{t(role.title)}</h2>
                  <p>{t(role.description)}</p>
                  <ul className="check-list">
                    {role.benefits.map((benefit) => (
                      <li key={benefit.en}>
                        <Check size={17} aria-hidden="true" />
                        {t(benefit)}
                      </li>
                    ))}
                  </ul>
                  {register(
                    role.id as Role,
                    role.action,
                    "button button-outline",
                    `register-${role.id}`,
                  )}
                </article>
              );
            })}
          </div>
        </section>
        <section className="container note-band">
          <ShieldCheck size={25} aria-hidden="true" />
          <p>
            {t(
              text(
                "Registration is not open yet. No personal information is requested or submitted by these options.",
                "ನೋಂದಣಿ ಇನ್ನೂ ಆರಂಭವಾಗಿಲ್ಲ. ಈ ಆಯ್ಕೆಗಳು ಯಾವುದೇ ವೈಯಕ್ತಿಕ ಮಾಹಿತಿಯನ್ನು ಕೇಳುವುದಿಲ್ಲ ಅಥವಾ ಸಲ್ಲಿಸುವುದಿಲ್ಲ.",
              ),
            )}
          </p>
        </section>
      </>
    );
  }

  return (
    <div className={`app locale-${lang}`}>
      <a
        href="#main-content"
        className="skip-link"
        onClick={(event) => {
          event.preventDefault();
          mainRef.current?.focus();
          mainRef.current?.scrollIntoView();
        }}
      >
        {t(text("Skip to content", "ವಿಷಯಕ್ಕೆ ತೆರಳಿ"))}
      </a>
      <div className="flag-line" aria-hidden="true" />
      <header className="site-header">
        <div className="container header-inner">
          {link(
            "home",
            <>
              <span className="brand-mark" aria-hidden="true">
                <BrandEmblem />
              </span>
              <span className="brand-type">
                <strong className="brand-wordmark">{t(text("KARAVE KOUSHALYA", "ಕರವೇ ಕೌಶಲ್ಯ"))}</strong>
                <span>
                  {t(
                    text(
                      "An initiative of Karnataka Rakshana Vedike",
                      "ಕರ್ನಾಟಕ ರಕ್ಷಣಾ ವೇದಿಕೆಯ ಉಪಕ್ರಮ",
                    ),
                  )}
                </span>
              </span>
            </>,
            "brand",
            {
              "aria-label": t(
                text("Karave Koushalya home", "ಕರವೇ ಕೌಶಲ್ಯ ಮುಖಪುಟ"),
              ),
            },
          )}
          <nav
            className="desktop-nav"
            aria-label={t(text("Main navigation", "ಮುಖ್ಯ ಸಂಚರಣೆ"))}
          >
            {pages
              .filter((p) => p !== "join")
              .map((item) => (
                <a
                  href={`#/${item}`}
                  key={item}
                  aria-current={page === item ? "page" : undefined}
                >
                  {t(nav[item])}
                </a>
              ))}
          </nav>
          <div className="header-actions">
            <button
              className="language-toggle"
              onClick={() => setLang(lang === "kn" ? "en" : "kn")}
              lang={lang === "kn" ? "en" : "kn"}
              aria-label={lang === "kn" ? "English" : "ಕನ್ನಡ"}
              title={lang === "kn" ? "Switch to English" : "ಕನ್ನಡಕ್ಕೆ ಬದಲಿಸಿ"}
            >
              <Languages size={16} aria-hidden="true" />
              <span>{lang === "kn" ? "English" : "ಕನ್ನಡ"}</span>
            </button>
            {link(
              "join",
              <>
                {t(text("Get started", "ನಮ್ಮೊಂದಿಗೆ ಸೇರಿ"))}
                <ArrowUpRight size={16} aria-hidden="true" />
              </>,
              "button button-dark header-join",
            )}
            <button
              ref={menuButtonRef}
              className="menu-toggle"
              aria-label={t(
                menuOpen
                  ? text("Close menu", "ಮೆನು ಮುಚ್ಚಿ")
                  : text("Open menu", "ಮೆನು ತೆರೆಯಿರಿ"),
              )}
              aria-expanded={menuOpen}
              aria-controls="mobile-nav"
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? (
                <X aria-hidden="true" />
              ) : (
                <Menu aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
        {menuOpen && (
          <nav
            id="mobile-nav"
            className="mobile-nav"
            aria-label={t(text("Mobile navigation", "ಮೊಬೈಲ್ ಸಂಚರಣೆ"))}
          >
            {pages.map((item) => (
              <a
                href={`#/${item}`}
                key={item}
                aria-current={page === item ? "page" : undefined}
                onClick={() => setMenuOpen(false)}
              >
                {t(nav[item])}
                <ArrowUpRight size={17} aria-hidden="true" />
              </a>
            ))}
          </nav>
        )}
      </header>
      <main ref={mainRef} id="main-content" tabIndex={-1}>
        {page === "home"
          ? Home()
          : page === "pathways"
            ? Pathways()
            : page === "programs"
              ? Programs()
              : page === "mentorship"
                ? Mentorship()
                : page === "about"
                  ? About()
                  : Join()}
      </main>
      <footer className="site-footer">
        <div className="container footer-main">
          <div className="footer-brand">
            {link(
              "home",
              <>
                <span className="brand-mark" aria-hidden="true">
                  <BrandEmblem />
                </span>
                <span className="brand-type">
                  <strong>{t(text("KARAVE KOUSHALYA", "ಕರವೇ ಕೌಶಲ್ಯ"))}</strong>
                  <span>
                    {t(
                      text(
                        "Learning. Skills. Employment.",
                        "ಕಲಿಕೆ. ಕೌಶಲ್ಯ. ಉದ್ಯೋಗ.",
                      ),
                    )}
                  </span>
                </span>
              </>,
              "brand",
            )}
            <p>
              {t(
                text(
                  "Rooted in our language.\nInvested in our people.\nBuilding Karnataka’s tomorrow.",
                  "ನಮ್ಮ ನುಡಿಯ ನೆಲೆಯಲ್ಲಿ.\nನಮ್ಮ ಜನರ ಸಬಲೀಕರಣಕ್ಕೆ.\nನಾಳಿನ ಕರ್ನಾಟಕ ನಿರ್ಮಾಣಕ್ಕೆ.",
                ),
              )}
            </p>
            <span className="footer-domain">karavekoushalya.com</span>
          </div>
          <div>
            <h3>{t(text("Discover", "ಅರಿಯಿರಿ"))}</h3>
            {(["pathways", "programs", "mentorship", "about"] as Page[]).map(
              (item) => (
                <a href={`#/${item}`} className="footer-link" key={item}>
                  {t(nav[item])}
                </a>
              ),
            )}
          </div>
          <div>
            <h3>{t(text("Be part of it", "ನೀವೂ ಪಾಲ್ಗೊಳ್ಳಿ"))}</h3>
            {roles
              .filter((role) => role.id !== "admin")
              .map((role) => (
                <button
                  className="footer-link"
                  key={role.id}
                  onClick={() => setRegistration(role.id as Role)}
                >
                  {t(role.title)}
                  <ArrowUpRight size={13} aria-hidden="true" />
                </button>
              ))}
          </div>
          <div className="footer-vision">
            <span className="small-label">
              {t(text("OUR SHARED VISION", "ನಮ್ಮೆಲ್ಲರ ಧ್ಯೇಯ"))}
            </span>
            <p lang="kn">
              ಕನ್ನಡಿಗರಿಗೆ ಕೌಶಲ್ಯ.
              <br />
              ಪ್ರತಿಯೊಬ್ಬರಿಗೂ ಉದ್ಯೋಗ.
            </p>
            <span className="footer-flag" aria-hidden="true" />
          </div>
        </div>
        <div className="container footer-bottom">
          <span>
            © {new Date().getFullYear()}{" "}
            {t(
              text(
                "Karave Koushalya. A Karnataka Rakshana Vedike initiative.",
                "ಕರವೇ ಕೌಶಲ್ಯ. ಕರ್ನಾಟಕ ರಕ್ಷಣಾ ವೇದಿಕೆಯ ಉಪಕ್ರಮ.",
              ),
            )}
          </span>
          <span>
            {t(
              text(
                "Programs planned · Registration coming soon",
                "ಪ್ರಸ್ತಾವಿತ ಕಾರ್ಯಕ್ರಮಗಳು · ನೋಂದಣಿ ಶೀಘ್ರದಲ್ಲೇ",
              ),
            )}
          </span>
          <button
            onClick={() => setRegistration("admin")}
            data-testid="register-admin-footer"
          >
            {t(text("Administrator access", "ನಿರ್ವಾಹಕರ ಪ್ರವೇಶ"))}
            <ArrowUpRight size={13} aria-hidden="true" />
          </button>
        </div>
      </footer>
      <RegistrationDialog
        lang={lang}
        role={registration}
        onClose={() => setRegistration(null)}
      />
    </div>
  );
}

function RegistrationDialog({
  lang,
  role,
  onClose,
}: {
  lang: Lang;
  role: Role | null;
  onClose: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const t = (value: Localized) => value[lang];
  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (role && !dialog.open) dialog.showModal();
    if (!role && dialog.open) dialog.close();
  }, [role]);
  const selected = roles.find((item) => item.id === role);
  return (
    <dialog
      ref={ref}
      className="registration-dialog"
      aria-labelledby="registration-title"
      aria-describedby="registration-description"
      onClose={onClose}
      onClick={(event) => {
        if (event.target === event.currentTarget) ref.current?.close();
      }}
    >
      <div className="dialog-inner">
        <button
          className="dialog-close"
          aria-label={t(text("Close", "ಮುಚ್ಚಿ"))}
          onClick={() => ref.current?.close()}
        >
          <X size={21} aria-hidden="true" />
        </button>
        <span className="dialog-icon">
          <Sparkles size={32} strokeWidth={1.5} aria-hidden="true" />
        </span>
        <span className="small-label">{selected ? t(selected.title) : ""}</span>
        <h2 id="registration-title" lang="en">
          The option coming soon
        </h2>
        <p id="registration-description">
          {t(
            text(
              "We’re getting ready to welcome you. Registration for this role will open in a future release.",
              "ನಿಮ್ಮನ್ನು ಸ್ವಾಗತಿಸಲು ಸಿದ್ಧರಾಗುತ್ತಿದ್ದೇವೆ. ಈ ಪಾತ್ರದ ನೋಂದಣಿ ಮುಂದಿನ ಆವೃತ್ತಿಯಲ್ಲಿ ಆರಂಭವಾಗಲಿದೆ.",
            ),
          )}
        </p>
        <p className="dialog-note">
          {t(
            text(
              "No personal information has been collected.",
              "ಯಾವುದೇ ವೈಯಕ್ತಿಕ ಮಾಹಿತಿಯನ್ನು ಸಂಗ್ರಹಿಸಿಲ್ಲ.",
            ),
          )}
        </p>
        <button
          className="button button-red"
          onClick={() => ref.current?.close()}
        >
          {t(text("Got it", "ಸರಿ, ಅರ್ಥವಾಯಿತು"))}
          <Check size={18} aria-hidden="true" />
        </button>
      </div>
    </dialog>
  );
}
