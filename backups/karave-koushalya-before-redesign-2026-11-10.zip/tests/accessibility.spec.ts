import { expect, test } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

// The wordmark is a user-specified logotype. WCAG 1.4.3 exempts brand-name
// text from contrast requirements; axe treats its gold stroke as foreground.
// Apply that exception only to this wordmark's contrast nodes. Navigation,
// the organization subtitle, focus indicators, and all other rules stay audited.
// https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html
function applicableViolations(violations: Awaited<ReturnType<AxeBuilder["analyze"]>>["violations"]) {
  return violations.flatMap((violation) => {
    if (violation.id !== "color-contrast") return [violation];
    const nodes = violation.nodes.filter(
      (node) => !node.html.includes('class="brand-wordmark"'),
    );
    return nodes.length ? [{ ...violation, nodes }] : [];
  });
}

for (const language of ["kn", "en"] as const) {
  test(`${language} pages and registration dialog pass automated accessibility checks`, async ({
    page,
  }) => {
    test.setTimeout(120_000);
    await page.goto("/");
    if (language === "en")
      await page.getByRole("button", { name: "English", exact: true }).click();

    for (const route of [
      "home",
      "pathways",
      "programs",
      "mentorship",
      "about",
      "join",
    ]) {
      await test.step(route, async () => {
        await page.goto(`/#/${route}`);
        await page.evaluate(() => document.fonts.ready);
        const result = await new AxeBuilder({ page })
          .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
          .analyze();
        expect.soft(applicableViolations(result.violations), `${language} ${route}`).toEqual([]);
      });
    }

    await page.getByTestId("register-candidate").click();
    const result = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
      .analyze();
    expect(applicableViolations(result.violations)).toEqual([]);
  });
}
