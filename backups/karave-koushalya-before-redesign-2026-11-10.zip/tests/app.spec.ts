import { expect, test, type Page } from "@playwright/test";

async function english(page: Page) {
  await page.goto("/");
  await page.getByRole("button", { name: "English", exact: true }).click();
  await expect(page.locator("html")).toHaveAttribute("lang", "en");
}

test("starts in Kannada, switches language, and remembers the choice", async ({
  page,
}) => {
  await page.goto("/");
  await expect(page.locator("html")).toHaveAttribute("lang", "kn");
  await page.getByRole("button", { name: "English", exact: true }).click();
  await expect(page.locator("html")).toHaveAttribute("lang", "en");
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("lang", "en");
  await page.getByRole("button", { name: "ಕನ್ನಡ", exact: true }).click();
  await expect(page.locator("html")).toHaveAttribute("lang", "kn");
});

test("uses the supplied portrait and labels the initiative as planned", async ({
  page,
}) => {
  await english(page);
  const portrait = page.locator('img[src*="narayana-gowda"]');
  await expect(portrait).toBeVisible();
  await expect
    .poll(() =>
      portrait.evaluate(
        (image: HTMLImageElement) => image.complete && image.naturalWidth > 0,
      ),
    )
    .toBe(true);
  await expect(
    page.getByText(/planned|coming soon|in the making/i).first(),
  ).toBeVisible();
});

test("all five registration roles show the coming-soon dialog without collecting data", async ({
  page,
}) => {
  await english(page);
  await page.goto("/#/join");
  const writes: string[] = [];
  page.on("request", (request) => {
    if (!["GET", "HEAD", "OPTIONS"].includes(request.method()))
      writes.push(request.url());
  });
  await expect(page.locator("form, input, textarea")).toHaveCount(0);
  for (const role of ["candidate", "corporate", "mentor", "mentee", "admin"]) {
    const registration = page.getByTestId(`register-${role}`);
    await registration.click();
    const dialog = page.getByRole("dialog");
    await expect(dialog).toBeVisible();
    await expect(
      dialog.getByRole("heading", {
        name: "The option coming soon",
        exact: true,
      }),
    ).toBeVisible();
    await page.keyboard.press("Escape");
    await expect(dialog).not.toBeVisible();
    await expect(registration).toBeFocused();
  }
  expect(writes).toEqual([]);
});

test("Kannada registration keeps the required message and translated explanation", async ({
  page,
}) => {
  await page.goto("/#/join");
  await page.getByTestId("register-candidate").click();
  const dialog = page.getByRole("dialog");
  await expect(
    dialog.getByRole("heading", {
      name: "The option coming soon",
      exact: true,
    }),
  ).toBeVisible();
  await expect(dialog).toContainText(/[\u0C80-\u0CFF]/);
  await dialog.getByRole("button", { name: "ಮುಚ್ಚಿ", exact: true }).click();
  await expect(dialog).not.toBeVisible();
});

test("all content views render without horizontal overflow in both languages", async ({
  page,
}) => {
  await english(page);
  const routes: Record<string, string> = {
    home: "",
    pathways: "A path for every ambition.",
    programs: "Learn. Grow. Move forward.",
    mentorship: "A little guidance. A bigger future.",
    about: "From advocacy to opportunity.",
    join: "Your next chapter starts here.",
  };
  for (const language of ["en", "kn"]) {
    if (language === "kn")
      await page.getByRole("button", { name: "ಕನ್ನಡ", exact: true }).click();
    for (const [route, heading] of Object.entries(routes)) {
      await page.goto(`/#/${route}`);
      await expect(page.locator("main h1")).toBeVisible();
      if (language === "en" && heading)
        await expect(
          page.getByRole("heading", { name: heading, exact: true }),
        ).toBeVisible();
      await expect(page.locator("html")).toHaveAttribute("lang", language);
      const dimensions = await page.evaluate(() => ({
        content: document.documentElement.scrollWidth,
        viewport: document.documentElement.clientWidth,
      }));
      expect(
        dimensions.content,
        `${language} ${route} should fit the viewport`,
      ).toBeLessThanOrEqual(dimensions.viewport + 1);
    }
  }
});

test("navigation supports browser history and mobile menu access", async ({
  page,
}, testInfo) => {
  await english(page);
  if (testInfo.project.name.includes("mobile")) {
    await page.getByRole("button", { name: "Open menu", exact: true }).click();
  }
  await page
    .getByRole("navigation")
    .first()
    .getByRole("link", { name: "Career pathways", exact: true })
    .click();
  await expect(page).toHaveURL(/#\/pathways$/);
  if (testInfo.project.name.includes("mobile")) {
    await page.getByRole("button", { name: "Open menu", exact: true }).click();
  }
  await page
    .getByRole("navigation")
    .first()
    .getByRole("link", { name: "Programs", exact: true })
    .click();
  await expect(page).toHaveURL(/#\/programs$/);
  await page.goBack();
  await expect(page).toHaveURL(/#\/pathways$/);
  await expect(
    page.getByRole("heading", {
      name: "A path for every ambition.",
      exact: true,
    }),
  ).toBeVisible();
});

test("career tabs support keyboard selection, boundary keys, and matching panels", async ({
  page,
}) => {
  await english(page);
  await page.goto("/#/pathways");
  const tabs = page.getByRole("tab");
  await expect(tabs).toHaveCount(4);
  await tabs.nth(0).focus();

  for (const [key, index] of [
    ["ArrowRight", 1],
    ["End", 3],
    ["Home", 0],
    ["ArrowLeft", 3],
    ["ArrowRight", 0],
  ] as const) {
    await page.keyboard.press(key);
    const selected = tabs.nth(index);
    await expect(selected).toBeFocused();
    await expect(selected).toHaveAttribute("aria-selected", "true");
    await expect(page.getByRole("tab", { selected: true })).toHaveCount(1);
    const panelId = await selected.getAttribute("aria-controls");
    const tabId = await selected.getAttribute("id");
    const panel = page.getByRole("tabpanel");
    await expect(panel).toHaveCount(1);
    await expect(panel).toHaveAttribute("id", panelId!);
    await expect(panel).toHaveAttribute("aria-labelledby", tabId!);
  }
});

test("Escape closes the mobile menu and returns focus to its toggle", async ({
  page,
}, testInfo) => {
  test.skip(
    !testInfo.project.name.includes("mobile"),
    "The mobile navigation is hidden on desktop.",
  );
  await english(page);
  await page.getByRole("button", { name: "Open menu", exact: true }).click();
  const menu = page.getByRole("navigation", {
    name: "Mobile navigation",
    exact: true,
  });
  await expect(menu).toBeVisible();
  await menu
    .getByRole("link", { name: "Career pathways", exact: true })
    .focus();
  await page.keyboard.press("Escape");
  await expect(menu).not.toBeVisible();
  const toggle = page.getByRole("button", { name: "Open menu", exact: true });
  await expect(toggle).toBeFocused();
  await expect(toggle).toHaveAttribute("aria-expanded", "false");
});

test("routes, language changes, tabs, and registration dialogs produce no browser errors", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(`page: ${error.message}`));
  page.on("console", (message) => {
    if (message.type() === "error") errors.push(`console: ${message.text()}`);
  });
  await english(page);
  for (const route of [
    "home",
    "pathways",
    "programs",
    "mentorship",
    "about",
    "join",
  ]) {
    await page.goto(`/#/${route}`);
    await expect(page.locator("main h1")).toBeVisible();
    if (route === "pathways") await page.getByRole("tab").last().click();
    if (route === "join") {
      await page.getByTestId("register-corporate").click();
      await page
        .getByRole("dialog")
        .getByRole("button", { name: "Close", exact: true })
        .click();
    }
  }
  await page.getByRole("button", { name: "ಕನ್ನಡ", exact: true }).click();
  await expect(page.locator("html")).toHaveAttribute("lang", "kn");
  expect(errors).toEqual([]);
});
