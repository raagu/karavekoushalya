# Karave Koushalya

A bilingual Kannada / English React + TypeScript application introducing the Karave Koushalya initiative. Built with Vite, with local fonts, responsive layouts, the supplied T. A. Narayana Gowda portrait, and keyboard-accessible registration dialogs.

## Run locally

Requires Node.js 22.18 or newer and npm.

```sh
npm ci
npm run dev
```

Open the local address printed by Vite. Kannada is the default language; the language toggle remembers the visitor's preference on that browser.

## Build and verify

```sh
npm run build
npm test
```

The browser suite checks desktop and mobile layouts, language persistence, navigation, the portrait, the five registration roles, dialog keyboard dismissal and focus return, and the absence of personal-data collection. If Chromium is not installed, run `npx playwright install chromium` first. The configuration can also reuse an existing Chromium cache, or accept `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH`.

```sh
npm run preview
```

The production output is in `dist/`. It can be hosted by a static web server. Hash-based routes work without server-side route rewrites.

## Scope

- Home, career pathways, programs, mentorship, about/roadmap, and joining views.
- Full Group A–D content, skilling and certification plans, student chapters, guilds, job and skill fairs, mentorship, CSR participation, and all three flagship programs.
- Registration entry points for candidates, corporates/employers, mentors, mentees, and administrators.
- Every registration action displays **The option coming soon**. No registration forms, accounts, database, analytics, or registration requests are implemented.
- Only the language preference is saved in browser storage. The app makes no third-party font or image requests at runtime.
- All partnerships, credentials, enrollment figures, and milestones are presented as plans and targets, as requested. No real achievements, scheme approvals, guaranteed jobs, or financing approvals are implied.

## Content and assets

`src/content.ts` contains the bilingual program content. `src/App.tsx` contains the view structure and bilingual interface text. `src/styles.css` contains the Karnataka yellow/red theme and responsive styles.

Content source: the user-provided `karave_koushalya.md`. Portrait source: the user-provided `narayana_gowdru.jpeg`, copied unchanged to `public/images/narayana-gowda.jpeg`. The custom KaRaVe Koushalya logo is saved as `public/images/karave-koushalya-logo-v3.png` and used in the header, footer, home-page portrait caption, and browser icon. Its Kannada letter “ಕ” represents Kannada identity, and its gear motif represents skill and capability, using Karnataka’s red and gold palette. The bilingual wordmark remains live text for sharp display and correct language switching.

DM Sans and Noto Sans Kannada are bundled locally under their SIL Open Font Licenses; license files are included in `public/fonts/`.

This release is ready for local review. Production domain setup, hosting, backend registration, identity/access control, storage, and operational monitoring are separate future work.
